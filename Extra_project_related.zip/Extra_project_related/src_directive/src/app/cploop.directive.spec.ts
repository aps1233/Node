import { CploopDirective } from './cploop.directive';

describe('CploopDirective', () => {
  it('should create an instance', () => {
    const directive = new CploopDirective();
    expect(directive).toBeTruthy();
  });
});
