import { DelayDirective } from './delay.directive';

describe('DelayDirective', () => {
  it('should create an instance', () => {
    const directive = new DelayDirective();
    expect(directive).toBeTruthy();
  });
});
