import { StrDirective } from './str.directive';

describe('StrDirective', () => {
  it('should create an instance', () => {
    const directive = new StrDirective();
    expect(directive).toBeTruthy();
  });
});
