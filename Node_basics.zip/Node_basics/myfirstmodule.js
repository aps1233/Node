exports.myfun = function() {
    var x = '';
    var x = Date();
    return x;
}